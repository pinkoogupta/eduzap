import React, { useState, useEffect } from 'react';
import SearchBar from '../components/SearchBar.jsx';
import SortButton from '../components/SortButton.jsx';
import Pagination from '../components/Pagination.jsx';
import RequestStats from '../components/RequestStats.jsx';
import RequestTable from '../components/RequestTable.jsx';

const API_BASE = "http://localhost:4000/api/v1/requests";

const Home = () => {
  const [requests, setRequests] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [sortOrder, setSortOrder] = useState("asc");
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState(""); // debounce state
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // 🔹 Debounce search term (300ms delay)
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(searchTerm), 300);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  // 🔹 Fetch requests (runs only when dependencies change)
  useEffect(() => {
    const fetchRequests = async () => {
      try {
        setLoading(true);
        setError("");

        let url = `${API_BASE}/get?page=${currentPage}&limit=5`;

        if (debouncedSearch) {
          url = `${API_BASE}/search?title=${encodeURIComponent(
            debouncedSearch
          )}&page=${currentPage}&limit=5`;
        } else if (sortOrder !== "asc") {
          url = `${API_BASE}/sorted?order=${sortOrder}&page=${currentPage}&limit=5`;
        }

        console.log("Fetching from:", url);
        const response = await fetch(url);
        if (!response.ok)
          throw new Error(`HTTP error! status: ${response.status}`);

        const result = await response.json();
        console.log("API Response:", result);

        if (result.success && result.data) {
          setRequests(result.data.items || []);
          setTotalPages(result.data.totalPages || 1);
          setCurrentPage(result.data.page || currentPage);
        } else {
          throw new Error(result.error || "Invalid response format");
        }
      } catch (err) {
        console.error("Fetch error:", err);
        setRequests([]);
        setError(err.message || "Failed to load requests. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchRequests();
  }, [currentPage, sortOrder, debouncedSearch]);

  // 🔹 Delete without refetching everything
  const handleDelete = async (id) => {
    try {
      const response = await fetch(`${API_BASE}/del/${id}`, { method: "DELETE" });
      if (!response.ok) throw new Error("Failed to delete request");
      setRequests((prev) => prev.filter((req) => req._id !== id));
    } catch (err) {
      console.error("Delete error:", err);
      setError("Failed to delete request");
    }
  };

  return (
    <div style={{ padding: "20px", maxWidth: "1200px", margin: "0 auto" }}>
      <h1 style={{ textAlign: "center", marginBottom: "20px" }}>
        EDUZAP LLP Request Dashboard
      </h1>

      {/* Error message */}
      {error && (
        <div style={{ color: "red", marginBottom: "10px" }}>
          ⚠️ {error}
        </div>
      )}

      <SearchBar
        search={searchTerm}
        setSearch={setSearchTerm}
        onClear={() => setSearchTerm("")}
      />
      <SortButton sortAsc={sortOrder === "asc"} onSort={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")} />
      <RequestStats requests={requests} />

      {loading ? (
        <p>Loading...</p>
      ) : (
        <RequestTable requests={requests} onDelete={handleDelete} />
      )}

      <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={setCurrentPage}
      />
    </div>
  );
};

export default Home;
